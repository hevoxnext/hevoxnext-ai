# HevoxNEXT Resume Matcher

This is the official AI-powered Resume & Job Description Matcher tool for HevoxNEXT.

## Features
- Predicts job category from resume
- Calculates semantic similarity with JD
- Streamlit interface
